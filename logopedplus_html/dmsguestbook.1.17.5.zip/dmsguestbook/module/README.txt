Define your own selectbox for DMSGuestbook

1.) Create a file which you want to fill it with your values and save this with .txt at the end. (e.g: MySelectbox.txt)
2.) Fill your selectable list and close each word with ";" at the end.
3.) Save the file and select the selectbox on DMSGuestbook admin panel: "extended -> Additional selectbox:".

Examples:
- - - - - - - - - -
Sun;
Moon;
Star;
[...]

I am working as Dentist;
I am working as Stewardess;
[...]

My hobbies are: skating, playing football;
My hobbies are: watching tv, listening music;
[...]
- - - - - - - - - -

Enjoy it!