**********************************************************************
You will find additional language template here:
http://danielschurter.net/dmsguestbook/language/index.html
**********************************************************************

######################################################################
You can write your own language template if you want.
Save your finished language file with the prefix .txt (e.g: english2.txt)
in the language folder in your dmsguestbook directory.
A code sample will you found below.

Special chars should be quotet. Like: � � � (&auml; &uuml; &ouml;)
http://www.w3.org/MarkUp/html-spec/html-spec_13.html
Or ask google for "html special characters" :-)
######################################################################

Sample:

<name>Name</name>
<email>Email</email>
<url>Website</url>
<message>Text</message>
<antispam><b>Antispam measures</b><br />Please insert the letter and number combination into the text field before submitting the guestbook
entry.</antispam>
<mandatory>Mandatory</mandatory>
<submit>Inscribe</submit>
<name_error>Name is too short!</name_error>
<email_error>Invalid email adress!</email_error>
<url_error>Invalid website adress!</url_error>
<message_error>Text is too short!</message_error>
<antispam_error>Wrong letter-figure combination!</antispam_error>
<success>Thank you for this guestbook entry!</success>
<admin_review>The administrator will check this post!<br />Thanks for your patience!</admin_review>